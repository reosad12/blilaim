package com.billiardaim

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class AimOverlayView(context: Context) : View(context) {

    private var cueBallX = 0f
    private var cueBallY = 0f
    private var aimX = 0f
    private var aimY = 0f
    private var isSetup = false
    private var settingCue = true

    private val linePaint = Paint().apply {
        color = Color.argb(220, 255, 230, 50)
        strokeWidth = 4f
        style = Paint.Style.STROKE
        isAntiAlias = true
        pathEffect = DashPathEffect(floatArrayOf(25f, 12f), 0f)
    }

    private val extendLinePaint = Paint().apply {
        color = Color.argb(150, 255, 120, 50)
        strokeWidth = 3f
        style = Paint.Style.STROKE
        isAntiAlias = true
        pathEffect = DashPathEffect(floatArrayOf(12f, 18f), 0f)
    }

    private val cueBallPaint = Paint().apply {
        color = Color.argb(220, 80, 180, 255)
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val targetPaint = Paint().apply {
        color = Color.argb(220, 255, 60, 60)
        style = Paint.Style.STROKE
        strokeWidth = 4f
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 44f
        isAntiAlias = true
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(5f, 0f, 0f, Color.BLACK)
    }

    private val bgPaint = Paint().apply {
        color = Color.argb(120, 0, 0, 0)
        style = Paint.Style.FILL
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (!isSetup || settingCue) {
                    cueBallX = event.x
                    cueBallY = event.y
                    aimX = 0f
                    aimY = 0f
                    settingCue = false
                    isSetup = true
                } else {
                    aimX = event.x
                    aimY = event.y
                    settingCue = true
                }
                invalidate()
                return true
            }
        }
        return false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (!isSetup) {
            drawHintText(canvas, "مرحله ۱: روی توپ سفید لمس کنید", height / 2f - 30f)
            return
        }

        // Draw cue ball
        canvas.drawCircle(cueBallX, cueBallY, 22f, cueBallPaint)
        val cueBallStroke = Paint(cueBallPaint).apply {
            style = Paint.Style.STROKE
            color = Color.WHITE
            strokeWidth = 2f
        }
        canvas.drawCircle(cueBallX, cueBallY, 22f, cueBallStroke)

        if (!settingCue && aimX == 0f) {
            drawHintText(canvas, "مرحله ۲: روی توپ هدف لمس کنید", height / 2f - 30f)
            return
        }

        if (aimX != 0f) {
            val angle = atan2(aimY - cueBallY, aimX - cueBallX)

            // Main aim line
            canvas.drawLine(cueBallX, cueBallY, aimX, aimY, linePaint)

            // Extended line after target
            val extendLength = 600f
            val extEndX = aimX + cos(angle) * extendLength
            val extEndY = aimY + sin(angle) * extendLength
            canvas.drawLine(aimX, aimY, extEndX, extEndY, extendLinePaint)

            // Target circle
            canvas.drawCircle(aimX, aimY, 32f, targetPaint)
            canvas.drawCircle(aimX, aimY, 10f, targetPaint)

            // Cue direction line (opposite)
            val cueEndX = cueBallX - cos(angle) * 180f
            val cueEndY = cueBallY - sin(angle) * 180f
            val cuePaint = Paint(linePaint).apply {
                color = Color.argb(160, 200, 200, 200)
                pathEffect = null
            }
            canvas.drawLine(cueBallX, cueBallY, cueEndX, cueEndY, cuePaint)

            // Angle display
            val angleDeg = Math.toDegrees(angle.toDouble()).toInt()
            val displayAngle = if (angleDeg < 0) angleDeg + 360 else angleDeg
            drawInfoBox(canvas, "زاویه: $displayAngle°", 40f, 80f)
            drawHintText(canvas, "لمس مجدد = تنظیم توپ جدید", height - 60f)
        }
    }

    private fun drawInfoBox(canvas: Canvas, text: String, x: Float, y: Float) {
        val textW = textPaint.measureText(text)
        canvas.drawRoundRect(x - 10f, y - 50f, x + textW + 10f, y + 10f, 12f, 12f, bgPaint)
        canvas.drawText(text, x, y, textPaint)
    }

    private fun drawHintText(canvas: Canvas, text: String, y: Float) {
        val textW = textPaint.measureText(text)
        val x = (width - textW) / 2f
        canvas.drawRoundRect(x - 15f, y - 50f, x + textW + 15f, y + 10f, 12f, 12f, bgPaint)
        canvas.drawText(text, x, y, textPaint)
    }
}

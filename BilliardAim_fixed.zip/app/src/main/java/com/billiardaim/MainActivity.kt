package com.billiardaim

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)

        btnStart.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                Toast.makeText(this, "لطفاً مجوز نمایش روی برنامه‌ها را فعال کنید", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, AimOverlayService::class.java))
                Toast.makeText(this, "خط هدف‌گیری فعال شد", Toast.LENGTH_SHORT).show()
            }
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, AimOverlayService::class.java))
            Toast.makeText(this, "خط هدف‌گیری متوقف شد", Toast.LENGTH_SHORT).show()
        }
    }
}
